<div class="banner"></div> 

<footer class="footer" class="social-links" >

    <ul>
       <!-- Espacio donde se coloca la informacion referente a los direccionamientos de las redes sociales-->

      <li><a href="https://www.facebook.com/LavacarBlackandWhite" target="_blank"><i class="fa fa-facebook"></i></a></li>
      <li><a href="https://www.instagram.com/lavacarblackandwhite/?fbclid=IwAR0TDoFXNveIuTKvLhbIT7dTtwQ6eePYTSzwac7L2p3Tqgvwynk_l87L2xs" target="_blank"><i class="fa fa-instagram"></i></a></li>
      <li><a href="https://goo.gl/maps/GnBWBMYf4SxKNFkv9" target="_blank"><i class="fa fa-map-marker"></i></a></li>
    </ul>

</footer>



